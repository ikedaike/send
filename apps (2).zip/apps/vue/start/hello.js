let app = new Vue({
  el: '#app',
  data: {
    message: '皆さん、こんにちは！',
    url:'https://www.youtube.com/',
    attribute: 'href',
    twitter_url:'https://twitter.com',
    udemy_obj:{
      href:"https://www.udemy.com/",
      id:"10"
    },
    x:0,
    y:0,
  },
  methods:{
    sayHi(){
      this.message = 'hello vue'
      return 'Hi'
    },
    /* 
    eventオブジェクト(eventが行われたときに取得できるあらゆる情報)を取得できる
    例えば、マウスの位置はclientXという情報で取得される
    consoleで確認できる
    eventの引数はHTML側では必要ない
    */
    locateMouse(event){
      console.log(event)
      this.x = event.clientX
      this.y = event.clientY
    }
  }
});
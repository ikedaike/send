
import roboter.controller.conversation

def main():
    roboter.controller.conversation.talk_about_restaurant()

# このファイルが仮にimportされても予期せぬ実行が起きないように、このファイルを実行したときだけ動くようにする(他のファイルは書かない)
# デェフォルトでは書かれていなかったので、追記した
if __name__ == "__main__":
    main()

from roboter.controller import control
def main():
    control.robot_coversation()

if __name__ == "__main__":
    main()
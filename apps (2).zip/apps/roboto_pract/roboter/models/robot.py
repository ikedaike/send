class Robot(object):
    def __init__(self, robot_name):
        self.robot_name = robot_name

ROBOT_NAME = 'roboko'

class Roboko(Robot):
    def __init__(self, robot_name=ROBOT_NAME, user_name="", restaurant_name=""):
        super().__init__(robot_name)
        self.user_name = user_name
        self.restaurant_name = restaurant_name

    def hello(self):
        print('こんにちは。私は{}です。あなたの名前は何ですか'.format(self.robot_name))
        self.user_name = input()
    def quest_where_do_you_like(self):
        print('{}さん、どこのレストランが好きですか'.format(self.user_name))
        self.favorite_restaurant = input()
    def quest_yes_or_no(self):
        print('私のおすすめのレストランは{}です。\nこのレストランは好きですか'.format(self.restaurant_name))

    def goodby(self):
        print('{}さん、ありがとうございました。良い一日を。さようなら'.format(self.user_name))



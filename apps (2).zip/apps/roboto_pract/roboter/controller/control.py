from roboter.models import robot

def robot_coversation():
    robo = robot.Roboko()
    robo.hello()
    robo.quest_where_do_you_like()
    robo.goodby()
